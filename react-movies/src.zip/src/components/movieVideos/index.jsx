import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { getMovieVideos } from '../../api/tmdb-api';
import Spinner from '../spinner';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';

/**
 * MovieVideos component displays a YouTube video trailer for a specific movie.
 * 
 * @param {Object} props - Component props
 * @param {string} props.movieId - The ID of the movie to fetch videos for
 * @returns {JSX.Element} A responsive iframe showing the movie trailer or a loading spinner
 */
const MovieVideos = (props) => {
  const { movieId } = props;
  
  // Fetch movie videos using React Query
  const { data, error, isPending, isError } = useQuery({
    queryKey: ['movieVideos', { id: movieId }],
    queryFn: () => getMovieVideos(movieId), // Ensure movieId is passed to the API call
  });

  // Show loading spinner while fetching data
  if (isPending) {
    return <Spinner />;
  }

  // Display error message if the request fails
  if (isError) {
    return <h1>{error.message}</h1>;
  }

  // Safely extract videos array from the response
  const videos = data?.results || [];
  
  // Find the first YouTube trailer in the videos array
  const firstVideo = videos.find(video => video.site === 'YouTube');

  // Return null if no YouTube videos are available
  if (!firstVideo) return null;

  return (
    // Only render if firstVideo exists
    firstVideo && (
      <Grid container spacing={2} sx={{ mt: 4, mb: 4 }}>
        <Grid item xs={12} sm={6} md={4}>
          <Card>
            {/* 
              Embed YouTube video using iframe inside a CardMedia component
              - Uses the video key from the API to construct the YouTube embed URL
              - Responsive design with Material-UI Grid and Card components
              - Fullscreen capability enabled
            */}
            <CardMedia
              component="iframe"
              src={`https://www.youtube.com/embed/${firstVideo.key}`}
              title={firstVideo.name}
              sx={{
                width: '100%',
                border: 'none',
                aspectRatio: '16/9', // Maintain 16:9 aspect ratio for video
                minHeight: '200px'    // Ensure minimum height for better UX
              }}
              allowFullScreen
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            />
          </Card>
        </Grid>
      </Grid>
    )
  );
};

export default MovieVideos;

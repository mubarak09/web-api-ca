import React, { useContext } from "react";
import PropTypes from 'prop-types';
import { Link } from "react-router-dom";
// Context
import { MoviesContext } from "../../contexts/moviesContext";
// Material-UI Components
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import CardHeader from "@mui/material/CardHeader";
import Avatar from "@mui/material/Avatar";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Grid from "@mui/material/Grid";
// Icons
import FavoriteIcon from "@mui/icons-material/Favorite";
import CalendarIcon from "@mui/icons-material/CalendarTodayTwoTone";
import ThumbUpIcon from "@mui/icons-material/ThumbUp";
// Assets
import img from '../../images/film-poster-placeholder.png';


/**
 * MovieCard component displays a card with movie details including poster, title, release date, and rating.
 * It also provides actions like adding to favorites and navigation to movie details.
 * 
 * @component
 * @param {Object} props - Component props
 * @param {Object} props.movie - The movie object containing details to display
 * @param {Function} props.action - Function to render action buttons for the movie
 * @returns {JSX.Element} A card component displaying movie information
 */
export default function MovieCard({ movie, action }) {
  const { favorites, addToFavorites } = useContext(MoviesContext);

  // Check if current movie is in favorites and update its favorite status
  movie.favorite = !!favorites.find((id) => id === movie.id);

  /**
   * Handles adding the movie to favorites
   * @param {React.MouseEvent} e - The click event
   */
  const handleAddToFavorite = (e) => {
    e.preventDefault();
    addToFavorites(movie);
  };

  return (
    <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Card Header with Favorite Indicator */}
      <CardHeader
        avatar={
          movie.favorite && (
            <Avatar 
              sx={{ 
                backgroundColor: 'red',
                color: 'white',
                width: 32,
                height: 32
              }}
              aria-label="favorite"
            >
              <FavoriteIcon />
            </Avatar>
          )
        }
        title={
          <Typography 
            variant="h6" 
            component="h2"
            sx={{
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap',
              fontWeight: 'bold'
            }}
          >
            {movie.title}
          </Typography>
        }
        sx={{ 
          pb: 1,
          '& .MuiCardHeader-content': {
            overflow: 'hidden'
          }
        }}
      />

      {/* Movie Poster */}
      <CardMedia
        component="img"
        sx={{
          height: 500,
          objectFit: 'cover',
          width: '100%'
        }}
        image={
          movie.poster_path
            ? `https://image.tmdb.org/t/p/w500/${movie.poster_path}`
            : img
        }
        alt={`Poster for ${movie.title}`}
      />

      {/* Movie Details */}
      <CardContent sx={{ flexGrow: 1, p: 2 }}>
        <Grid container spacing={2}>
          <Grid item xs={6}>
            <Typography variant="body1" component="p" sx={{ display: 'flex', alignItems: 'center' }}>
              <CalendarIcon color="action" fontSize="small" sx={{ mr: 1 }} />
              {movie.release_date ? new Date(movie.release_date).getFullYear() : 'N/A'}
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography variant="body1" component="p" sx={{ display: 'flex', alignItems: 'center' }}>
              <ThumbUpIcon color="action" fontSize="small" sx={{ mr: 1 }} />
              {movie.vote_average ? `${Math.round(movie.vote_average * 10)}%` : 'N/A'}
            </Typography>
          </Grid>
        </Grid>
      </CardContent>

      {/* Action Buttons */}
      <CardActions sx={{ p: 2, mt: 'auto' }}>
        {action && typeof action === 'function' && action(movie)}
        <Button 
          component={Link} 
          to={`/movies/${movie.id}`}
          variant="outlined" 
          size="medium" 
          color="primary"
          fullWidth
        >
          More Info
        </Button>
      </CardActions>
    </Card>
  );
}

// Prop type validation
MovieCard.propTypes = {
  movie: PropTypes.shape({
    id: PropTypes.number.isRequired,
    title: PropTypes.string.isRequired,
    poster_path: PropTypes.string,
    release_date: PropTypes.string,
    vote_average: PropTypes.number,
    favorite: PropTypes.bool
  }).isRequired,
  action: PropTypes.func.isRequired
};

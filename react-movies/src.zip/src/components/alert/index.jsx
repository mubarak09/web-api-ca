import React, { useState, createContext, useContext } from 'react';
import PropTypes from 'prop-types';
import { Snackbar, Alert } from '@mui/material';

/**
 * Context for managing alert notifications throughout the application.
 * Provides a way to show temporary alert messages to the user.
 */
const AlertContext = createContext();

/**
 * AlertProvider component that manages the state and display of alert messages.
 * Wraps the application to provide alert functionality to all child components.
 * 
 * @component
 * @param {Object} props - Component props
 * @param {React.ReactNode} props.children - Child components that will have access to the alert context
 * @returns {JSX.Element} The AlertProvider component with context
 */
export const AlertProvider = ({ children }) => {
  // State to manage alert visibility and content
  const [alert, setAlert] = useState({
    open: false,
    message: '',
  });

  /**
   * Displays an alert message to the user
   * @param {string} message - The message to display in the alert
   */
  const showAlert = (message) => {
    setAlert({
      open: true,
      message,
    });
  };

  /**
   * Handles closing the alert
   * @private
   */
  const handleClose = () => {
    setAlert(prev => ({ ...prev, open: false }));
  };

  return (
    <AlertContext.Provider value={{ showAlert }}>
      {children}
      <Snackbar
        open={alert.open}
        autoHideDuration={6000} // Increased duration for better readability
        onClose={handleClose}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }} // Better positioning
        sx={{ marginTop: '20px' }} // Add some margin from the top
      >
        <Alert 
          onClose={handleClose} 
          severity="info" // Default severity
          variant="filled" // Better visibility
          sx={{ width: '100%' }}
        >
          {alert.message}
        </Alert>
      </Snackbar>
    </AlertContext.Provider>
  );
};

/**
 * Custom hook to access the alert context
 * @returns {Object} An object containing the showAlert function
 * @throws Will throw an error if used outside of an AlertProvider
 */
export const useAlert = () => {
  const context = useContext(AlertContext);
  if (context === undefined) {
    throw new Error('useAlert must be used within an AlertProvider');
  }
  return context;
};

// Prop type validation
AlertProvider.propTypes = {
  children: PropTypes.node.isRequired,
};

// Default export for better import syntax
export default AlertProvider;

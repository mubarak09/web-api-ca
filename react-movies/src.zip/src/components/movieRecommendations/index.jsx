import React from 'react';
import { getMovieRecommendations } from '../../api/tmdb-api';
import { useQuery } from '@tanstack/react-query';
import Spinner from '../spinner';
import Movie from '../movieCard';
import Grid from '@mui/material/Grid';

/**
 * MovieRecommendations component displays a grid of recommended movies based on the current movie.
 * 
 * @param {Object} props - Component props
 * @param {string} props.movieId - The ID of the movie to fetch recommendations for
 * @param {Function} [props.action] - Optional action to be performed on each movie card
 * @returns {JSX.Element} A grid of recommended movie cards or a loading spinner
 */
const MovieRecommendations = (props) => {
  const { movieId, action } = props;
  
  // Fetch movie recommendations using React Query
  const { data, error, isPending, isError } = useQuery({
    queryKey: ['movieRecommendations', { id: movieId }],
    queryFn: () => getMovieRecommendations(movieId), // Pass movieId to the API call
  });

  // Show loading spinner while fetching data
  if (isPending) {
    return <Spinner />;
  }

  // Display error message if the request fails
  if (isError) {
    return <h1>{error.message}</h1>;
  }

  // Safely extract recommendations array from the response
  const recommendations = data?.results || [];

  // Return null if there are no recommendations to display
  if (recommendations.length === 0) return null;

  /**
   * Create movie cards for the first 4 recommendations
   * Each card is wrapped in a responsive Grid component
   */
  const movieCards = recommendations
    .slice(0, 4) // Limit to first 4 recommendations
    .map((movie) => (
      <Grid 
        key={movie.id} 
        item 
        xs={12} sm={6} md={4} lg={3}
        sx={{ padding: '20px' }}
      >
        <Movie 
          movie={movie} 
          action={action || (() => {})} 
        />
      </Grid>
    ));
  
  return (
    <Grid container spacing={2}>
      {movieCards}
    </Grid>
  );
};

export default MovieRecommendations;
